
# Motivo SOP AI Dashboard

This is a full-stack AI-powered SOP management system with SmartSheet integration.

## 🚀 Getting Started

### 1. Install Node.js (https://nodejs.org)

### 2. Set up environment variables

Copy the backend `.env.template` file to `.env` and insert your SmartSheet API key.

### 3. Install dependencies

```
cd backend
npm install

cd ../frontend
npm install
```

### 4. Run the system

```
# In backend folder
npm start

# In frontend folder
npm start
```

### 5. Visit your dashboard

Frontend will be at: `http://localhost:3000`  
Backend API will be at: `http://localhost:5000/api/sops`

---
For full SmartSheet support, wire in SmartSheet API using the backend route `/api/sops`.

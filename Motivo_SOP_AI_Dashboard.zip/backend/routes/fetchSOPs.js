
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json([
    { title: 'Confined Space Entry', status: 'Complete' },
    { title: 'Fall Protection', status: 'In Progress' },
    { title: 'Chemical Safety', status: 'Not Started' }
  ]);
});

module.exports = router;

import React from "react";
import SOPDashboard from "./pages/SOPDashboard";

function App() {
  return <SOPDashboard />;
}

export default App;
